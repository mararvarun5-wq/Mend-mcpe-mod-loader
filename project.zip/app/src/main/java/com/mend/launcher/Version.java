package com.mend.launcher;

/** Dotted numeric versions like 1.26.62.1. Missing parts count as 0. */
final class Version {
    private Version() {}

    static int[] parse(String text) {
        if (text == null) throw new IllegalArgumentException("version is missing");
        String[] parts = text.trim().split("\\.", -1);
        int[] out = new int[parts.length];
        for (int i = 0; i < parts.length; i++) {
            if (!parts[i].matches("[0-9]{1,9}")) {
                throw new IllegalArgumentException("bad version '" + text + "'");
            }
            out[i] = Integer.parseInt(parts[i]);
        }
        return out;
    }

    static int compare(int[] a, int[] b) {
        int n = Math.max(a.length, b.length);
        for (int i = 0; i < n; i++) {
            int x = i < a.length ? a[i] : 0;
            int y = i < b.length ? b[i] : 0;
            if (x != y) return x < y ? -1 : 1;
        }
        return 0;
    }

    static boolean atLeast(String have, String need) {
        return compare(parse(have), parse(need)) >= 0;
    }

    /** lo and hi may be null (no limit). */
    static boolean inRange(String version, String lo, String hi) {
        int[] v = parse(version);
        if (lo != null && compare(v, parse(lo)) < 0) return false;
        if (hi != null && compare(v, parse(hi)) > 0) return false;
        return true;
    }
}
