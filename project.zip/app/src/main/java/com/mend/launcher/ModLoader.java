package com.mend.launcher;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.TreeMap;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Finds mods, works out load order, and builds the merged overlay folder. */
final class ModLoader {
    private ModLoader() {}

    static final long MAX_MOD_BYTES = 1024L * 1024 * 1024; // per mod, uncompressed
    static final long MAX_JSON_BYTES = 16L * 1024 * 1024; // files read into memory to merge
    static final int MAX_ENTRIES = 100000;
    static final String BUILD_MARKER = ".mend_build";

    // ------------------------------------------------------------ mod sources

    /** A mod on disk: either a folder or a .zip/.mend archive. */
    interface Source {
        String readManifest() throws IOException, ManifestException;

        /** Safe relative paths (with '/') of every file under filesDir, sorted. */
        List<String> files(String filesDir) throws IOException, ManifestException;

        byte[] read(String filesDir, String rel) throws IOException;

        void copyTo(String filesDir, String rel, File dest) throws IOException;
    }

    private static void makeParent(File dest) throws IOException {
        File parent = dest.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
            throw new IOException("cannot create folder " + parent);
        }
    }

    private static long copyCapped(InputStream in, OutputStream out, long cap) throws IOException {
        byte[] buf = new byte[64 * 1024];
        long total = 0;
        int n;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > cap) throw new IOException("file is larger than the allowed size");
            out.write(buf, 0, n);
        }
        return total;
    }

    static final class DirSource implements Source {
        final File root;

        DirSource(File root) {
            this.root = root;
        }

        @Override
        public String readManifest() throws IOException, ManifestException {
            File mf = new File(root, "manifest.json");
            if (!mf.isFile()) throw new ManifestException("manifest.json not found");
            return new String(Files.readAllBytes(mf.toPath()), StandardCharsets.UTF_8);
        }

        @Override
        public List<String> files(String filesDir) throws IOException, ManifestException {
            List<String> out = new ArrayList<>();
            File base = new File(root, filesDir);
            if (!base.isDirectory()) return out;
            if (Files.isSymbolicLink(base.toPath())) {
                throw new ManifestException("symlink not allowed in mod: " + filesDir);
            }
            walk(base, "", out);
            Collections.sort(out);
            return out;
        }

        private void walk(File dir, String prefix, List<String> out)
                throws IOException, ManifestException {
            File[] kids = dir.listFiles();
            if (kids == null) return;
            Arrays.sort(kids);
            for (File kid : kids) {
                Path p = kid.toPath();
                String rel = prefix + kid.getName();
                if (Files.isSymbolicLink(p)) {
                    throw new ManifestException("symlink not allowed in mod: " + rel);
                }
                if (kid.isDirectory()) {
                    walk(kid, rel + "/", out);
                } else if (kid.isFile()) {
                    if (!ModManifest.safeRelPath(rel)) {
                        throw new ManifestException("unsafe file path in mod: '" + rel + "'");
                    }
                    if (out.size() >= MAX_ENTRIES) {
                        throw new ManifestException("mod has too many files");
                    }
                    out.add(rel);
                }
            }
        }

        @Override
        public byte[] read(String filesDir, String rel) throws IOException {
            File f = new File(new File(root, filesDir), rel);
            if (f.length() > MAX_JSON_BYTES) throw new IOException("file too large to read: " + rel);
            return Files.readAllBytes(f.toPath());
        }

        @Override
        public void copyTo(String filesDir, String rel, File dest) throws IOException {
            makeParent(dest);
            Files.copy(new File(new File(root, filesDir), rel).toPath(), dest.toPath(),
                    StandardCopyOption.REPLACE_EXISTING);
        }
    }

    static final class ZipSource implements Source {
        final File file;

        ZipSource(File file) {
            this.file = file;
        }

        private ZipFile open() throws ManifestException {
            try {
                return new ZipFile(file);
            } catch (IOException e) {
                throw new ManifestException("not a valid zip file: " + e.getMessage());
            }
        }

        @Override
        public String readManifest() throws IOException, ManifestException {
            try (ZipFile z = open()) {
                ZipEntry e = z.getEntry("manifest.json");
                if (e == null) {
                    throw new ManifestException("manifest.json not found at the root of the archive");
                }
                try (InputStream in = z.getInputStream(e)) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    copyCapped(in, bos, 1024 * 1024);
                    return new String(bos.toByteArray(), StandardCharsets.UTF_8);
                }
            }
        }

        @Override
        public List<String> files(String filesDir) throws IOException, ManifestException {
            String prefix = filesDir + "/";
            List<String> out = new ArrayList<>();
            long total = 0;
            int count = 0;
            try (ZipFile z = open()) {
                Enumeration<? extends ZipEntry> en = z.entries();
                while (en.hasMoreElements()) {
                    ZipEntry e = en.nextElement();
                    if (e.isDirectory()) continue;
                    if (++count > MAX_ENTRIES) throw new ManifestException("archive has too many files");
                    String name = e.getName();
                    if (!ModManifest.safeRelPath(name)) {
                        throw new ManifestException("unsafe path in archive: '" + name + "'");
                    }
                    if (e.getSize() > 0) total += e.getSize();
                    if (total > MAX_MOD_BYTES) {
                        throw new ManifestException("archive expands to more than the allowed size");
                    }
                    if (name.startsWith(prefix)) {
                        String rel = name.substring(prefix.length());
                        if (!ModManifest.safeRelPath(rel)) {
                            throw new ManifestException("unsafe path in archive: '" + rel + "'");
                        }
                        out.add(rel);
                    }
                }
            }
            Collections.sort(out);
            return out;
        }

        @Override
        public byte[] read(String filesDir, String rel) throws IOException {
            try (ZipFile z = new ZipFile(file)) {
                ZipEntry e = z.getEntry(filesDir + "/" + rel);
                if (e == null) throw new IOException("missing in archive: " + rel);
                try (InputStream in = z.getInputStream(e)) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    copyCapped(in, bos, MAX_JSON_BYTES);
                    return bos.toByteArray();
                }
            }
        }

        @Override
        public void copyTo(String filesDir, String rel, File dest) throws IOException {
            makeParent(dest);
            try (ZipFile z = new ZipFile(file)) {
                ZipEntry e = z.getEntry(filesDir + "/" + rel);
                if (e == null) throw new IOException("missing in archive: " + rel);
                try (InputStream in = z.getInputStream(e);
                     OutputStream out = new FileOutputStream(dest)) {
                    copyCapped(in, out, MAX_MOD_BYTES);
                }
            }
        }
    }

    // -------------------------------------------------------------- discovery

    static final class Mod {
        final ModManifest manifest;
        final Source source;

        Mod(ModManifest manifest, Source source) {
            this.manifest = manifest;
            this.source = source;
        }

        String id() {
            return manifest.id;
        }
    }

    /** Something wrong with a mod. That mod is not loaded. */
    static final class Problem {
        final String where; // mod id, or file name if the manifest could not be read
        final String reason;

        Problem(String where, String reason) {
            this.where = where;
            this.reason = reason;
        }
    }

    static final class LoadResult {
        final List<Mod> mods;
        final List<Problem> problems;

        LoadResult(List<Mod> mods, List<Problem> problems) {
            this.mods = mods;
            this.problems = problems;
        }
    }

    /** Reads every mod in modsDir. Bad mods become Problems, never exceptions. */
    static LoadResult discover(File modsDir) {
        List<Mod> mods = new ArrayList<>();
        List<Problem> problems = new ArrayList<>();
        File[] entries = modsDir.listFiles();
        if (entries == null) return new LoadResult(mods, problems);
        Arrays.sort(entries);

        Map<String, String> seen = new HashMap<>(); // id -> entry name
        for (File entry : entries) {
            String fname = entry.getName();
            if (fname.startsWith(".")) continue;
            Source source;
            if (entry.isDirectory()) {
                source = new DirSource(entry);
            } else if (entry.isFile() && (fname.toLowerCase(Locale.ROOT).endsWith(".zip")
                    || fname.toLowerCase(Locale.ROOT).endsWith(".mend"))) {
                source = new ZipSource(entry);
            } else {
                continue;
            }
            ModManifest manifest;
            try {
                manifest = ModManifest.parse(source.readManifest());
                source.files(manifest.filesDir); // validate the file list now
            } catch (ManifestException | IOException e) {
                problems.add(new Problem(fname, String.valueOf(e.getMessage())));
                continue;
            }
            if (seen.containsKey(manifest.id)) {
                problems.add(new Problem(manifest.id, "duplicate id: already provided by "
                        + seen.get(manifest.id) + "; skipped " + fname));
                continue;
            }
            seen.put(manifest.id, fname);
            mods.add(new Mod(manifest, source));
        }
        return new LoadResult(mods, problems);
    }

    // ------------------------------------------------------------- resolution

    /**
     * Returns mods in load order plus problems. Mods with problems are left out.
     * gameVersion may be null to skip the game-version check.
     */
    static LoadResult resolve(List<Mod> mods, String gameVersion) {
        List<Problem> problems = new ArrayList<>();
        final Map<String, Mod> active = new TreeMap<>();
        for (Mod m : mods) active.put(m.id(), m);

        // 1. game version
        if (gameVersion != null) {
            for (String mid : new ArrayList<>(active.keySet())) {
                ModManifest m = active.get(mid).manifest;
                if (!Version.inRange(gameVersion, m.gameMin, m.gameMax)) {
                    problems.add(new Problem(mid, "supports game versions "
                            + (m.gameMin != null ? m.gameMin : "any") + " to "
                            + (m.gameMax != null ? m.gameMax : "any")
                            + ", but the game is " + gameVersion));
                    active.remove(mid);
                }
            }
        }

        // 2. dependencies (repeat: dropping one mod can break others)
        boolean changed = true;
        while (changed) {
            changed = false;
            for (String mid : new ArrayList<>(active.keySet())) {
                Mod mod = active.get(mid);
                if (mod == null) continue;
                for (ModManifest.Dependency dep : mod.manifest.dependencies) {
                    Mod other = active.get(dep.id);
                    String why = null;
                    if (other == null) {
                        why = "requires '" + dep.id + "', which is missing or could not be loaded";
                    } else if (dep.minVersion != null
                            && !Version.atLeast(other.manifest.version, dep.minVersion)) {
                        why = "requires '" + dep.id + "' >= " + dep.minVersion
                                + ", found " + other.manifest.version;
                    }
                    if (why != null) {
                        problems.add(new Problem(mid, why));
                        active.remove(mid);
                        changed = true;
                        break;
                    }
                }
            }
        }

        // 3. order: dependencies and load_after first; ties by (priority, id)
        Map<String, Set<String>> before = new HashMap<>(); // mod -> mods that must load first
        Map<String, List<String>> dependents = new HashMap<>();
        for (String mid : active.keySet()) {
            before.put(mid, new HashSet<String>());
            dependents.put(mid, new ArrayList<String>());
        }
        for (Map.Entry<String, Mod> e : active.entrySet()) {
            String mid = e.getKey();
            for (ModManifest.Dependency dep : e.getValue().manifest.dependencies) {
                before.get(mid).add(dep.id);
            }
            for (String other : e.getValue().manifest.loadAfter) {
                if (active.containsKey(other) && !other.equals(mid)) before.get(mid).add(other);
            }
        }
        Map<String, Integer> indegree = new HashMap<>();
        for (Map.Entry<String, Set<String>> e : before.entrySet()) {
            indegree.put(e.getKey(), e.getValue().size());
            for (String d : e.getValue()) dependents.get(d).add(e.getKey());
        }

        Comparator<String> cmp = new Comparator<String>() {
            @Override
            public int compare(String a, String b) {
                int c = Integer.compare(active.get(a).manifest.priority,
                        active.get(b).manifest.priority);
                return c != 0 ? c : a.compareTo(b);
            }
        };
        PriorityQueue<String> ready = new PriorityQueue<>(11, cmp);
        for (Map.Entry<String, Integer> e : indegree.entrySet()) {
            if (e.getValue() == 0) ready.add(e.getKey());
        }
        List<Mod> ordered = new ArrayList<>();
        while (!ready.isEmpty()) {
            String mid = ready.poll();
            ordered.add(active.get(mid));
            for (String next : dependents.get(mid)) {
                int left = indegree.get(next) - 1;
                indegree.put(next, left);
                if (left == 0) ready.add(next);
            }
        }

        if (ordered.size() != active.size()) {
            Set<String> placed = new HashSet<>();
            for (Mod m : ordered) placed.add(m.id());
            List<String> stuck = new ArrayList<>();
            for (String mid : active.keySet()) if (!placed.contains(mid)) stuck.add(mid);
            String names = join(stuck, ", ");
            for (String mid : stuck) {
                problems.add(new Problem(mid,
                        "circular dependency or load order involving: " + names));
            }
        }
        return new LoadResult(ordered, problems);
    }

    /** discover + resolve in one call. */
    static LoadResult loadAll(File modsDir, String gameVersion) {
        LoadResult found = discover(modsDir);
        LoadResult resolved = resolve(found.mods, gameVersion);
        List<Problem> all = new ArrayList<>(found.problems);
        all.addAll(resolved.problems);
        return new LoadResult(resolved.mods, all);
    }

    // ------------------------------------------------------------------ build

    static final class Conflict {
        final String path;
        final String winner;
        final List<String> overridden;

        Conflict(String path, String winner, List<String> overridden) {
            this.path = path;
            this.winner = winner;
            this.overridden = overridden;
        }
    }

    static final class BuildReport {
        File outDir;
        List<String> mods = new ArrayList<>();
        int filesWritten = 0;
        List<Conflict> conflicts = new ArrayList<>();
        List<String> jsonMerged = new ArrayList<>();
        List<String> warnings = new ArrayList<>();

        Map<String, Object> toMap() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("mods", new ArrayList<Object>(mods));
            m.put("files_written", Integer.valueOf(filesWritten));
            List<Object> cs = new ArrayList<>();
            for (Conflict c : conflicts) {
                Map<String, Object> cm = new LinkedHashMap<>();
                cm.put("path", c.path);
                cm.put("winner", c.winner);
                cm.put("overridden", new ArrayList<Object>(c.overridden));
                cs.add(cm);
            }
            m.put("conflicts", cs);
            m.put("json_merged", new ArrayList<Object>(jsonMerged));
            m.put("warnings", new ArrayList<Object>(warnings));
            return m;
        }
    }

    /** Objects merge key by key; everything else (lists, values) is replaced. */
    static Object deepMerge(Object base, Object over) {
        if (base instanceof Map && over instanceof Map) {
            Map<String, Object> out = new LinkedHashMap<>();
            for (Map.Entry<?, ?> e : ((Map<?, ?>) base).entrySet()) {
                out.put(String.valueOf(e.getKey()), e.getValue());
            }
            for (Map.Entry<?, ?> e : ((Map<?, ?>) over).entrySet()) {
                String k = String.valueOf(e.getKey());
                out.put(k, out.containsKey(k) ? deepMerge(out.get(k), e.getValue()) : e.getValue());
            }
            return out;
        }
        return over;
    }

    private static final class Planned {
        final Mod mod;
        final byte[] merged; // null = copy the file straight from the mod

        Planned(Mod mod, byte[] merged) {
            this.mod = mod;
            this.merged = merged;
        }
    }

    private static String utf8(byte[] b) {
        return new String(b, StandardCharsets.UTF_8);
    }

    private static String join(List<String> items, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(items.get(i));
        }
        return sb.toString();
    }

    private static void deleteRecursive(File f) throws IOException {
        // Never follow symlinks: delete the link itself.
        if (f.isDirectory() && !Files.isSymbolicLink(f.toPath())) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k);
        }
        if (!f.delete() && f.exists()) throw new IOException("cannot delete " + f);
    }

    /** Merges mods (in order, later wins) into outDir as an overlay folder. */
    static BuildReport build(List<Mod> ordered, File outDir) throws IOException {
        BuildReport report = new BuildReport();
        report.outDir = outDir;
        for (Mod m : ordered) report.mods.add(m.id());

        // Plan first (path -> where its bytes come from), write afterwards.
        Map<String, Planned> plan = new TreeMap<>();
        Map<String, List<String>> providers = new TreeMap<>();

        for (Mod mod : ordered) {
            String fdir = mod.manifest.filesDir;
            List<String> rels;
            try {
                rels = mod.source.files(fdir);
            } catch (ManifestException e) {
                throw new IOException(mod.id() + ": " + e.getMessage());
            }
            for (String rel : rels) {
                Planned prev = plan.get(rel);
                if (prev != null && mod.manifest.jsonMerge && rel.endsWith(".json")) {
                    try {
                        byte[] baseRaw = prev.merged != null ? prev.merged
                                : prev.mod.source.read(prev.mod.manifest.filesDir, rel);
                        Object a = Json.parse(utf8(baseRaw));
                        Object b = Json.parse(utf8(mod.source.read(fdir, rel)));
                        if (a instanceof Map && b instanceof Map) {
                            byte[] merged = Json.write(deepMerge(a, b), 2)
                                    .getBytes(StandardCharsets.UTF_8);
                            plan.put(rel, new Planned(mod, merged));
                            report.jsonMerged.add(rel);
                            providers.get(rel).add(mod.id());
                            continue;
                        }
                        report.warnings.add(rel + ": not a JSON object in both mods; "
                                + mod.id() + " replaces it instead of merging");
                    } catch (JsonException | IOException e) {
                        report.warnings.add(rel + ": could not read JSON from " + prev.mod.id()
                                + " or " + mod.id() + "; " + mod.id()
                                + " replaces it instead of merging");
                    }
                }
                plan.put(rel, new Planned(mod, null));
                List<String> who = providers.get(rel);
                if (who == null) {
                    who = new ArrayList<>();
                    providers.put(rel, who);
                }
                who.add(mod.id());
            }
        }

        Set<String> mergedPaths = new HashSet<>(report.jsonMerged);
        for (Map.Entry<String, List<String>> e : providers.entrySet()) {
            List<String> who = e.getValue();
            if (who.size() > 1 && !mergedPaths.contains(e.getKey())) {
                report.conflicts.add(new Conflict(e.getKey(), who.get(who.size() - 1),
                        new ArrayList<>(who.subList(0, who.size() - 1))));
            }
        }

        // Prepare the output folder. Refuse to wipe a folder Mend didn't create.
        if (outDir.exists()) {
            File[] kids = outDir.listFiles();
            boolean empty = kids == null || kids.length == 0;
            if (!empty && !new File(outDir, BUILD_MARKER).exists()) {
                throw new IOException(outDir + " is not empty and was not created by Mend; "
                        + "refusing to overwrite it");
            }
            if (kids != null) for (File k : kids) deleteRecursive(k);
        } else if (!outDir.mkdirs()) {
            throw new IOException("cannot create " + outDir);
        }
        Files.write(new File(outDir, BUILD_MARKER).toPath(),
                "Created by Mend. Safe to delete or rebuild.\n".getBytes(StandardCharsets.UTF_8));

        String root = outDir.getCanonicalPath() + File.separator;
        for (Map.Entry<String, Planned> e : plan.entrySet()) {
            String rel = e.getKey();
            Planned p = e.getValue();
            File dest = new File(outDir, rel);
            if (!dest.getCanonicalPath().startsWith(root)) { // defense in depth
                throw new IOException("refusing to write outside the output folder: " + rel);
            }
            if (p.merged != null) {
                makeParent(dest);
                Files.write(dest.toPath(), p.merged);
            } else {
                p.mod.source.copyTo(p.mod.manifest.filesDir, rel, dest);
            }
            report.filesWritten++;
        }

        Files.write(new File(outDir, "mend_build.json").toPath(),
                Json.write(report.toMap(), 2).getBytes(StandardCharsets.UTF_8));
        return report;
    }
}
