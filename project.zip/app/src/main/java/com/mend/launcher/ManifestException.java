package com.mend.launcher;

/** Thrown when a mod's manifest or file layout is invalid or unsafe. */
final class ManifestException extends Exception {
    ManifestException(String message) {
        super(message);
    }
}
