package com.mend.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

/**
 * Mend v0.1: a mod manager. It creates the mods folder, checks and orders the mods,
 * builds the merged overlay, and starts Minecraft normally.
 *
 * NOT done yet: making the game read from the overlay. See the README.
 */
public class MainActivity extends Activity {
    private static final String MC_PACKAGE = "com.mojang.minecraftpe";

    private TextView statusView;
    private File modsDir;
    private File overlayDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Mend's own folder under Android/media: the app can write there with no
        // permission, and file managers can open it on Android 11+.
        File base = getFilesDir();
        File[] media = getExternalMediaDirs();
        if (media != null && media.length > 0 && media[0] != null) base = media[0];
        modsDir = new File(base, "mods");
        overlayDir = new File(base, "overlay");
        modsDir.mkdirs();

        buildUi();
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (statusView != null) refresh(); // pick up mods copied while Mend was in the background
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        return b;
    }

    private void buildUi() {
        int pad = dp(16);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Mend");
        title.setTextSize(30);
        root.addView(title);

        root.addView(button("Launch Minecraft", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchMinecraft();
            }
        }));
        root.addView(button("Rescan mods", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refresh();
            }
        }));
        root.addView(button("Build overlay", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buildOverlay();
            }
        }));

        statusView = new TextView(this);
        statusView.setTextIsSelectable(true);
        statusView.setPadding(0, pad, 0, 0);
        root.addView(statusView);

        scroll.addView(root);
        setContentView(scroll);
    }

    /** Installed Minecraft version name, or null if Minecraft is not installed. */
    private String minecraftVersion() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(MC_PACKAGE, 0);
            return info.versionName == null ? "unknown" : info.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    /** Version usable for compatibility checks, or null if it can't be parsed. */
    private String checkableVersion(String versionName) {
        if (versionName == null) return null;
        try {
            Version.parse(versionName);
            return versionName;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private void launchMinecraft() {
        Intent intent = getPackageManager().getLaunchIntentForPackage(MC_PACKAGE);
        if (intent == null) {
            Toast.makeText(this, "Minecraft is not installed", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(intent);
    }

    private void show(final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                statusView.setText(text);
            }
        });
    }

    private void refresh() {
        statusView.setText("Scanning...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                show(describe());
            }
        }).start();
    }

    private String describe() {
        StringBuilder sb = new StringBuilder();
        try {
            String mc = minecraftVersion();
            sb.append("Minecraft: ").append(mc == null ? "not installed" : mc).append("\n");
            sb.append("Mods folder:\n").append(modsDir.getAbsolutePath()).append("\n\n");

            ModLoader.LoadResult result = ModLoader.loadAll(modsDir, checkableVersion(mc));
            if (result.mods.isEmpty()) {
                sb.append("No mods loaded. Copy mod folders or .zip files into the folder above.\n");
            } else {
                sb.append("Mods in load order:\n");
                int i = 1;
                for (ModLoader.Mod m : result.mods) {
                    sb.append(i++).append(". ").append(m.manifest.name)
                            .append(" (").append(m.id()).append(") v")
                            .append(m.manifest.version).append("\n");
                }
            }
            if (!result.problems.isEmpty()) {
                sb.append("\nSkipped:\n");
                for (ModLoader.Problem p : result.problems) {
                    sb.append("- ").append(p.where).append(": ").append(p.reason).append("\n");
                }
            }
            sb.append("\nNote: this version manages and checks mods. It does not change the game yet.");
        } catch (Throwable t) {
            sb.append("\nSomething went wrong while scanning:\n").append(t);
        }
        return sb.toString();
    }

    private void buildOverlay() {
        statusView.setText("Building...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                StringBuilder sb = new StringBuilder();
                try {
                    String mc = minecraftVersion();
                    ModLoader.LoadResult result = ModLoader.loadAll(modsDir, checkableVersion(mc));
                    ModLoader.BuildReport report = ModLoader.build(result.mods, overlayDir);
                    sb.append("Built ").append(report.filesWritten).append(" file(s) from ")
                            .append(report.mods.size()).append(" mod(s) into:\n")
                            .append(overlayDir.getAbsolutePath()).append("\n");
                    for (ModLoader.Conflict c : report.conflicts) {
                        sb.append("\nConflict: ").append(c.path).append("\n  ")
                                .append(c.winner).append(" overrides ");
                        for (int i = 0; i < c.overridden.size(); i++) {
                            if (i > 0) sb.append(", ");
                            sb.append(c.overridden.get(i));
                        }
                        sb.append("\n");
                    }
                    for (String w : report.warnings) sb.append("\nWarning: ").append(w).append("\n");
                    for (ModLoader.Problem p : result.problems) {
                        sb.append("\nSkipped ").append(p.where).append(": ").append(p.reason).append("\n");
                    }
                } catch (Throwable t) {
                    sb.append("Build failed:\n").append(t);
                }
                show(sb.toString());
            }
        }).start();
    }
}
