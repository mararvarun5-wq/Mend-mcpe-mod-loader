package com.mend.launcher;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/** A mod's manifest.json, validated. Same rules as the Python core. */
final class ModManifest {
    static final int MEND_API = 1;
    private static final Pattern ID_RE = Pattern.compile("^[a-z0-9][a-z0-9_-]{1,63}$");

    static final class Dependency {
        final String id;
        final String minVersion; // may be null

        Dependency(String id, String minVersion) {
            this.id = id;
            this.minVersion = minVersion;
        }
    }

    String id;
    String name;
    String version;
    String description = "";
    List<String> authors = new ArrayList<>();
    String gameMin;
    String gameMax;
    List<Dependency> dependencies = new ArrayList<>();
    List<String> loadAfter = new ArrayList<>();
    int priority = 0;
    String filesDir = "files";
    boolean jsonMerge = false;

    /** True if rel is a plain relative path that cannot escape its folder. */
    static boolean safeRelPath(String rel) {
        if (rel == null || rel.isEmpty()) return false;
        if (rel.indexOf('\\') >= 0 || rel.indexOf('\0') >= 0 || rel.startsWith("/")) return false;
        String[] parts = rel.split("/", -1);
        for (String part : parts) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) return false;
        }
        return !parts[0].matches("[A-Za-z]:"); // windows drive letter
    }

    private static void expect(boolean ok, String message) throws ManifestException {
        if (!ok) throw new ManifestException(message);
    }

    private static boolean isInt(Object o) {
        return o instanceof Long || o instanceof Integer;
    }

    /** Value for key, treating an explicit JSON null as "not set". */
    private static Object val(Map<?, ?> m, String key) {
        Object v = m.get(key);
        return v == Json.NULL ? null : v;
    }

    private static List<String> stringList(Object o, String what) throws ManifestException {
        expect(o instanceof List, what + " must be a list");
        List<String> out = new ArrayList<>();
        for (Object x : (List<?>) o) {
            expect(x instanceof String, what + " must contain only strings");
            out.add((String) x);
        }
        return out;
    }

    private static String optionalVersion(Object o, String what) throws ManifestException {
        if (o == null) return null;
        expect(o instanceof String, what + " must be a version string");
        try {
            Version.parse((String) o);
        } catch (IllegalArgumentException e) {
            throw new ManifestException(what + ": " + e.getMessage());
        }
        return (String) o;
    }

    static ModManifest parse(String raw) throws ManifestException {
        Object root;
        try {
            root = Json.parse(raw);
        } catch (JsonException e) {
            throw new ManifestException("manifest.json is not valid JSON: " + e.getMessage());
        }
        expect(root instanceof Map, "manifest.json must be a JSON object");
        Map<?, ?> m = (Map<?, ?>) root;

        for (String key : new String[] {"id", "name", "version"}) {
            expect(val(m, key) != null, "manifest is missing required field '" + key + "'");
        }

        ModManifest mf = new ModManifest();

        Object id = val(m, "id");
        expect(id instanceof String && ID_RE.matcher((String) id).matches(),
                "id must be 2-64 chars: lowercase letters, digits, '-' or '_', "
                        + "starting with a letter or digit");
        mf.id = (String) id;

        Object name = val(m, "name");
        expect(name instanceof String && !((String) name).trim().isEmpty(),
                "name must be a non-empty string");
        mf.name = (String) name;

        mf.version = optionalVersion(val(m, "version"), "version");

        Object api = val(m, "mend_api");
        if (api != null) {
            expect(isInt(api), "mend_api must be an integer");
            long n = ((Number) api).longValue();
            expect(n == MEND_API,
                    "mod targets Mend API " + n + ", this Mend supports API " + MEND_API);
        }

        Object gv = val(m, "game_versions");
        if (gv != null) {
            expect(gv instanceof Map, "game_versions must be an object with optional min/max");
            Map<?, ?> g = (Map<?, ?>) gv;
            mf.gameMin = optionalVersion(val(g, "min"), "game_versions.min");
            mf.gameMax = optionalVersion(val(g, "max"), "game_versions.max");
        }

        Object deps = val(m, "dependencies");
        if (deps != null) {
            expect(deps instanceof List, "dependencies must be a list");
            List<String> seen = new ArrayList<>();
            for (Object d : (List<?>) deps) {
                expect(d instanceof Map && ((Map<?, ?>) d).get("id") instanceof String,
                        "each dependency must be an object with an 'id' string");
                Map<?, ?> dm = (Map<?, ?>) d;
                String depId = (String) dm.get("id");
                expect(!depId.equals(mf.id), "a mod cannot depend on itself");
                expect(!seen.contains(depId), "dependency '" + depId + "' listed twice");
                seen.add(depId);
                String minV = optionalVersion(val(dm, "min_version"),
                        "dependency '" + depId + "' min_version");
                mf.dependencies.add(new Dependency(depId, minV));
            }
        }

        Object la = val(m, "load_after");
        if (la != null) mf.loadAfter = stringList(la, "load_after");

        Object pr = val(m, "priority");
        if (pr != null) {
            expect(isInt(pr), "priority must be an integer");
            long p = ((Number) pr).longValue();
            expect(p >= -1000000 && p <= 1000000, "priority must be between -1000000 and 1000000");
            mf.priority = (int) p;
        }

        Object fd = val(m, "files_dir");
        if (fd != null) {
            expect(fd instanceof String && safeRelPath((String) fd),
                    "files_dir must be a safe relative folder name");
            mf.filesDir = (String) fd;
        }

        Object au = val(m, "authors");
        if (au != null) mf.authors = stringList(au, "authors");

        Object desc = val(m, "description");
        if (desc != null) mf.description = String.valueOf(desc);

        Object jm = val(m, "json_merge");
        if (jm != null) {
            expect(jm instanceof Boolean, "json_merge must be true or false");
            mf.jsonMerge = (Boolean) jm;
        }
        return mf;
    }
}
