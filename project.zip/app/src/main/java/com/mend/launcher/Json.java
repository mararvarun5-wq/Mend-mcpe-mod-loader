package com.mend.launcher;

import java.math.BigInteger;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tiny strict JSON reader/writer so Mend needs no libraries.
 * Objects become LinkedHashMap, arrays ArrayList, integers Long,
 * decimals Double, and JSON null becomes {@link #NULL}.
 */
final class Json {
    private Json() {}

    static final Object NULL = new Object() {
        @Override
        public String toString() {
            return "null";
        }
    };

    /** Stops hostile mods from crashing Mend with absurdly nested files. */
    private static final int MAX_DEPTH = 100;
    private static final Pattern NUMBER =
            Pattern.compile("-?(0|[1-9][0-9]*)(\\.[0-9]+)?([eE][+-]?[0-9]+)?");

    static Object parse(String text) throws JsonException {
        if (text == null) throw new JsonException("empty input");
        if (text.startsWith("﻿")) text = text.substring(1); // UTF-8 BOM
        Parser p = new Parser(text);
        p.skipWs();
        Object v = p.value(0);
        p.skipWs();
        if (p.pos != text.length()) throw p.error("unexpected data after the JSON value");
        return v;
    }

    private static final class Parser {
        final String s;
        int pos = 0;

        Parser(String s) {
            this.s = s;
        }

        JsonException error(String msg) {
            return new JsonException(msg + " (at character " + pos + ")");
        }

        void skipWs() {
            while (pos < s.length()) {
                char c = s.charAt(pos);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r') pos++;
                else break;
            }
        }

        Object value(int depth) throws JsonException {
            if (depth > MAX_DEPTH) throw error("JSON is nested too deeply");
            if (pos >= s.length()) throw error("unexpected end of input");
            char c = s.charAt(pos);
            switch (c) {
                case '{':
                    return object(depth);
                case '[':
                    return array(depth);
                case '"':
                    return string();
                case 't':
                    literal("true");
                    return Boolean.TRUE;
                case 'f':
                    literal("false");
                    return Boolean.FALSE;
                case 'n':
                    literal("null");
                    return NULL;
                default:
                    return number();
            }
        }

        void literal(String word) throws JsonException {
            if (!s.startsWith(word, pos)) throw error("invalid value");
            pos += word.length();
        }

        Map<String, Object> object(int depth) throws JsonException {
            Map<String, Object> out = new LinkedHashMap<>();
            pos++; // {
            skipWs();
            if (pos < s.length() && s.charAt(pos) == '}') {
                pos++;
                return out;
            }
            while (true) {
                skipWs();
                if (pos >= s.length() || s.charAt(pos) != '"') throw error("expected a string key");
                String key = string();
                skipWs();
                if (pos >= s.length() || s.charAt(pos) != ':') throw error("expected ':'");
                pos++;
                skipWs();
                out.put(key, value(depth + 1));
                skipWs();
                if (pos >= s.length()) throw error("unexpected end of input");
                char c = s.charAt(pos++);
                if (c == '}') return out;
                if (c != ',') throw error("expected ',' or '}'");
            }
        }

        List<Object> array(int depth) throws JsonException {
            List<Object> out = new ArrayList<>();
            pos++; // [
            skipWs();
            if (pos < s.length() && s.charAt(pos) == ']') {
                pos++;
                return out;
            }
            while (true) {
                skipWs();
                out.add(value(depth + 1));
                skipWs();
                if (pos >= s.length()) throw error("unexpected end of input");
                char c = s.charAt(pos++);
                if (c == ']') return out;
                if (c != ',') throw error("expected ',' or ']'");
            }
        }

        String string() throws JsonException {
            pos++; // opening quote
            StringBuilder sb = new StringBuilder();
            while (true) {
                if (pos >= s.length()) throw error("unterminated string");
                char c = s.charAt(pos++);
                if (c == '"') return sb.toString();
                if (c < 0x20) throw error("control character in string");
                if (c != '\\') {
                    sb.append(c);
                    continue;
                }
                if (pos >= s.length()) throw error("unterminated escape");
                char e = s.charAt(pos++);
                switch (e) {
                    case '"': sb.append('"'); break;
                    case '\\': sb.append('\\'); break;
                    case '/': sb.append('/'); break;
                    case 'b': sb.append('\b'); break;
                    case 'f': sb.append('\f'); break;
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'u': {
                        if (pos + 4 > s.length()) throw error("bad \\u escape");
                        int code = 0;
                        for (int i = 0; i < 4; i++) {
                            int d = Character.digit(s.charAt(pos + i), 16);
                            if (d < 0) throw error("bad \\u escape");
                            code = code * 16 + d;
                        }
                        sb.append((char) code);
                        pos += 4;
                        break;
                    }
                    default:
                        throw error("bad escape");
                }
            }
        }

        Object number() throws JsonException {
            Matcher m = NUMBER.matcher(s);
            m.region(pos, s.length());
            if (!m.lookingAt()) throw error("invalid value");
            String tok = m.group();
            boolean isDecimal = m.group(2) != null || m.group(3) != null;
            pos = m.end();
            if (isDecimal) return Double.valueOf(Double.parseDouble(tok));
            BigInteger bi = new BigInteger(tok);
            if (bi.bitLength() < 64) return Long.valueOf(bi.longValue());
            return Double.valueOf(bi.doubleValue());
        }
    }

    // ---------------------------------------------------------------- writer

    static String write(Object value, int indent) {
        StringBuilder sb = new StringBuilder();
        write(sb, value, indent, 0);
        return sb.toString();
    }

    private static void write(StringBuilder sb, Object v, int indent, int level) {
        if (v == null || v == NULL) {
            sb.append("null");
        } else if (v instanceof String) {
            quote(sb, (String) v);
        } else if (v instanceof Boolean || v instanceof Long || v instanceof Integer) {
            sb.append(v);
        } else if (v instanceof Double) {
            double d = (Double) v;
            if (Double.isNaN(d) || Double.isInfinite(d)) sb.append("null");
            else sb.append(d);
        } else if (v instanceof Map) {
            Map<?, ?> m = (Map<?, ?>) v;
            if (m.isEmpty()) {
                sb.append("{}");
                return;
            }
            sb.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                if (!first) sb.append(',');
                first = false;
                newline(sb, indent, level + 1);
                quote(sb, String.valueOf(e.getKey()));
                sb.append(indent > 0 ? ": " : ":");
                write(sb, e.getValue(), indent, level + 1);
            }
            newline(sb, indent, level);
            sb.append('}');
        } else if (v instanceof List) {
            List<?> list = (List<?>) v;
            if (list.isEmpty()) {
                sb.append("[]");
                return;
            }
            sb.append('[');
            boolean first = true;
            for (Object item : list) {
                if (!first) sb.append(',');
                first = false;
                newline(sb, indent, level + 1);
                write(sb, item, indent, level + 1);
            }
            newline(sb, indent, level);
            sb.append(']');
        } else {
            throw new IllegalArgumentException("unsupported JSON type: " + v.getClass().getName());
        }
    }

    private static void newline(StringBuilder sb, int indent, int level) {
        if (indent <= 0) return;
        sb.append('\n');
        for (int i = 0; i < indent * level; i++) sb.append(' ');
    }

    private static void quote(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        sb.append('"');
    }
}
