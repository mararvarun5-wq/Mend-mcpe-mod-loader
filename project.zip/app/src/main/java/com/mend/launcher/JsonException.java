package com.mend.launcher;

/** Thrown when text is not valid JSON. */
final class JsonException extends Exception {
    JsonException(String message) {
        super(message);
    }
}
