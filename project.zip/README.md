# Mend launcher (v0.1.0)

Android app that manages Mend mods for Minecraft Bedrock. It does NOT modify
Minecraft; it is a separate app.

## What v0.1 does
- Creates a mods folder: `Android/media/com.mend.launcher/mods/`
- Reads mods (folders, `.zip`, `.mend`), checks manifests, game version and dependencies
- Shows them in load order, and lists any that were skipped and why
- "Build overlay": merges all mods into `Android/media/com.mend.launcher/overlay/`
- "Launch Minecraft": starts the normal installed game

## What it does NOT do yet
Mods do not change the game yet. Making Minecraft read from the overlay is the
next step and needs testing on a real phone, one small step at a time.

## Build
GitHub Actions builds the APK. See `.github/workflows/build.yml` (kept in the
GitHub repo, not in this zip).

## Test the loader logic (needs a JDK, no Android SDK)
    ./core-tests/run.sh
