#!/bin/sh
# Compile and run the core tests. Needs a JDK (17 or newer). No Android SDK needed.
set -e
cd "$(dirname "$0")/.."
OUT="${TMPDIR:-/tmp}/mend_core_tests"
rm -rf "$OUT"
mkdir -p "$OUT"
javac --release 17 -d "$OUT" \
  app/src/main/java/com/mend/launcher/Json.java \
  app/src/main/java/com/mend/launcher/JsonException.java \
  app/src/main/java/com/mend/launcher/ManifestException.java \
  app/src/main/java/com/mend/launcher/Version.java \
  app/src/main/java/com/mend/launcher/ModManifest.java \
  app/src/main/java/com/mend/launcher/ModLoader.java \
  core-tests/com/mend/launcher/CoreTests.java
LC_ALL=C.UTF-8 java -cp "$OUT" com.mend.launcher.CoreTests
