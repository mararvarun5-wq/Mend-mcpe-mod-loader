package com.mend.launcher;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Plain-Java tests for the Mend core (no JUnit, no Android).
 * Run: see core-tests/run.sh
 */
public class CoreTests {
    interface Body { void run() throws Exception; }

    static int passed = 0;
    static final List<String> failures = new ArrayList<>();

    static void test(String name, Body body) {
        try {
            body.run();
            passed++;
            System.out.println("ok    " + name);
        } catch (Throwable t) {
            failures.add(name + ": " + t);
            System.out.println("FAIL  " + name + "  ->  " + t);
        }
    }

    static void eq(Object expected, Object actual) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError("expected <" + expected + "> but was <" + actual + ">");
        }
    }

    static void yes(boolean cond, String what) {
        if (!cond) throw new AssertionError(what);
    }

    static void no(boolean cond, String what) {
        if (cond) throw new AssertionError(what);
    }

    static void bad(Body body, String what) {
        try {
            body.run();
        } catch (Exception e) {
            return;
        }
        throw new AssertionError("expected an error: " + what);
    }

    // ---------------------------------------------------------------- helpers

    static File tmp() throws IOException {
        File d = Files.createTempDirectory("mendtest").toFile();
        d.deleteOnExit();
        return d;
    }

    static void write(File f, String content) throws IOException {
        f.getParentFile().mkdirs();
        Files.write(f.toPath(), content.getBytes(StandardCharsets.UTF_8));
    }

    static String read(File f) throws IOException {
        return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
    }

    /** extra is raw JSON members, e.g. "\"priority\": -5". files = path, content, path, content... */
    static File mod(File mods, String id, String extra, String... files) throws IOException {
        File d = new File(mods, id);
        d.mkdirs();
        String mf = "{\"id\":\"" + id + "\",\"name\":\"" + id + "\",\"version\":\"1.0.0\""
                + (extra.isEmpty() ? "" : "," + extra) + "}";
        write(new File(d, "manifest.json"), mf);
        for (int i = 0; i < files.length; i += 2) {
            write(new File(new File(d, "files"), files[i]), files[i + 1]);
        }
        return d;
    }

    static void zip(File target, String... nameContentPairs) throws IOException {
        try (ZipOutputStream z = new ZipOutputStream(Files.newOutputStream(target.toPath()))) {
            for (int i = 0; i < nameContentPairs.length; i += 2) {
                z.putNextEntry(new ZipEntry(nameContentPairs[i]));
                z.write(nameContentPairs[i + 1].getBytes(StandardCharsets.UTF_8));
                z.closeEntry();
            }
        }
    }

    static List<String> ids(ModLoader.LoadResult r) {
        List<String> out = new ArrayList<>();
        for (ModLoader.Mod m : r.mods) out.add(m.id());
        return out;
    }

    static List<String> problemIds(ModLoader.LoadResult r) {
        List<String> out = new ArrayList<>();
        for (ModLoader.Problem p : r.problems) out.add(p.where);
        Collections.sort(out);
        return out;
    }

    static String reason(ModLoader.LoadResult r, String where) {
        for (ModLoader.Problem p : r.problems) if (p.where.equals(where)) return p.reason;
        throw new AssertionError("no problem reported for " + where);
    }

    static Object parse(String s) throws Exception {
        return Json.parse(s);
    }

    // ------------------------------------------------------------------- main

    public static void main(String[] args) throws Exception {
        jsonTests();
        versionAndPathTests();
        manifestTests();
        resolveTests();
        discoveryTests();
        buildTests();

        System.out.println();
        System.out.println(passed + " passed, " + failures.size() + " failed");
        for (String f : failures) System.out.println("  - " + f);
        System.exit(failures.isEmpty() ? 0 : 1);
    }

    // ------------------------------------------------------------------- json

    static void jsonTests() {
        test("json: scalars, arrays, objects", () -> {
            eq(Long.valueOf(42), parse("42"));
            eq(Long.valueOf(-7), parse("-7"));
            eq(Double.valueOf(1.5), parse("1.5"));
            eq(Double.valueOf(1000.0), parse("1e3"));
            eq(Boolean.TRUE, parse("true"));
            eq(Boolean.FALSE, parse(" false "));
            yes(parse("null") == Json.NULL, "null");
            eq("hi", parse("\"hi\""));
            eq(Arrays.asList(1L, 2L, 3L), parse("[1, 2,3]"));
            Map<?, ?> m = (Map<?, ?>) parse("{\"a\": {\"b\": [true]}}");
            eq(Collections.singletonList(Boolean.TRUE), ((Map<?, ?>) m.get("a")).get("b"));
        });
        test("json: string escapes", () -> {
            eq("a\"b\\c/d\n\t", parse("\"a\\\"b\\\\c\\/d\\n\\t\""));
            eq("\u00e9", parse("\"\\u00e9\""));
            bad(() -> parse("\"\\u12G4\""), "bad hex");
            bad(() -> parse("\"\\q\""), "bad escape");
            bad(() -> parse("\"abc"), "unterminated");
            bad(() -> parse("\"line\nbreak\""), "raw newline");
        });
        test("json: rejects invalid input", () -> {
            for (String s : new String[] {"", "{", "[1,]", "{\"a\":1,}", "{'a':1}", "{a:1}",
                    "01", "1.", "-", "tru", "nul", "[1 2]", "{\"a\" 1}", "1 2", "// c\n{}",
                    "{\"a\":}", "[,1]"}) {
                final String in = s;
                bad(() -> parse(in), "input: " + in);
            }
        });
        test("json: UTF-8 BOM is ignored", () -> eq(Long.valueOf(1), parse("\uFEFF1")));
        test("json: absurd nesting is rejected, not a stack overflow", () -> {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 100000; i++) sb.append('[');
            final String deep = sb.toString();
            bad(() -> parse(deep), "deep nesting");
        });
        test("json: huge integers fall back to double", () ->
                yes(parse("123456789012345678901234567890") instanceof Double, "double"));
        test("json: write then parse round-trips", () -> {
            String src = "{\"a\":{\"x\":1,\"y\":[1,2,{\"z\":null}]},\"s\":\"q\\\"\\n\",\"t\":true,\"f\":1.5}";
            Object once = parse(src);
            String pretty = Json.write(once, 2);
            eq(once.toString(), parse(pretty).toString());
            yes(pretty.contains("\n  \"a\""), "indented");
            eq(src.replace("1.5", "1.5"), Json.write(once, 0));
        });
    }

    // --------------------------------------------------------- version & path

    static void versionAndPathTests() {
        test("version: compare pads zeros", () -> {
            yes(Version.atLeast("1.21", "1.21.0"), "1.21 >= 1.21.0");
            yes(Version.atLeast("1.26.62.1", "1.26.5"), "4-part");
            no(Version.atLeast("1.9.0", "1.10.0"), "1.9 < 1.10");
            yes(Version.inRange("1.21.40", "1.21.0", null), "no max");
            no(Version.inRange("1.20.9", "1.21.0", null), "below min");
            no(Version.inRange("1.22.0", null, "1.21.99"), "above max");
        });
        test("version: junk is rejected", () -> {
            for (String s : new String[] {"", "1.x", "1..2", "v1", "1.2.3-beta", " "}) {
                final String in = s;
                bad(() -> Version.parse(in), in);
            }
        });
        test("safeRelPath", () -> {
            yes(ModManifest.safeRelPath("a/b/c.json"), "plain");
            for (String s : new String[] {"", "/etc/passwd", "../x", "a/../../x", "a\\b", "C:/x",
                    "a//b", "./a", "a/", "a/./b"}) {
                no(ModManifest.safeRelPath(s), s);
            }
        });
    }

    // --------------------------------------------------------------- manifest

    static void manifestTests() {
        test("manifest: valid minimal", () ->
                eq("my-mod", ModManifest.parse("{\"id\":\"my-mod\",\"name\":\"My\",\"version\":\"1.2.3\"}").id));
        test("manifest: all fields", () -> {
            ModManifest m = ModManifest.parse("{\"id\":\"my-mod\",\"name\":\"My\",\"version\":\"1.2.3\","
                    + "\"game_versions\":{\"min\":\"1.21\",\"max\":\"1.30\"},"
                    + "\"dependencies\":[{\"id\":\"lib-x\",\"min_version\":\"2.0\"}],"
                    + "\"load_after\":[\"other\"],\"priority\":-3,\"json_merge\":true,"
                    + "\"authors\":[\"me\"],\"description\":\"d\",\"mend_api\":1}");
            eq("1.21", m.gameMin);
            eq("2.0", m.dependencies.get(0).minVersion);
            eq(-3, m.priority);
            yes(m.jsonMerge, "json_merge");
        });
        test("manifest: rejects bad JSON and non-objects", () -> {
            for (String s : new String[] {"{nope", "[]", "\"x\"", ""}) {
                final String in = s;
                bad(() -> ModManifest.parse(in), in);
            }
        });
        test("manifest: rejects bad fields", () -> {
            String base = "\"id\":\"ok-mod\",\"name\":\"x\",\"version\":\"1.0\"";
            String[] extras = {
                    "\"id\":\"Bad Id\"", "\"id\":\"a\"", "\"id\":\"../evil\"",
                    "\"version\":\"1.x\"", "\"version\":1", "\"mend_api\":99", "\"mend_api\":true",
                    "\"files_dir\":\"../out\"", "\"files_dir\":\"/abs\"", "\"priority\":\"high\"",
                    "\"json_merge\":\"yes\"", "\"dependencies\":[{\"id\":\"ok-mod\"}]",
                    "\"dependencies\":[{\"id\":\"x1\"},{\"id\":\"x1\"}]", "\"dependencies\":{}",
                    "\"game_versions\":[]", "\"game_versions\":{\"min\":\"abc\"}",
                    "\"load_after\":[1]", "\"authors\":\"me\"", "\"priority\":99999999999"};
            for (String extra : extras) {
                final String json = "{" + base + "," + extra + "}";
                bad(() -> ModManifest.parse(json), extra);
            }
        });
        test("manifest: missing required field", () ->
                bad(() -> ModManifest.parse("{\"id\":\"abc\",\"name\":\"x\"}"), "no version"));
    }

    // ---------------------------------------------------------------- resolve

    static void resolveTests() {
        test("resolve: dependency loads first", () -> {
            File mods = tmp();
            mod(mods, "aaa-addon", "\"dependencies\":[{\"id\":\"zzz-lib\"}]");
            mod(mods, "zzz-lib", "");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(Arrays.asList("zzz-lib", "aaa-addon"), ids(r));
            eq(0, r.problems.size());
        });
        test("resolve: priority then id, deterministic", () -> {
            File mods = tmp();
            mod(mods, "bbb-mod", "");
            mod(mods, "aaa-mod", "");
            mod(mods, "ccc-mod", "\"priority\":-5");
            eq(Arrays.asList("ccc-mod", "aaa-mod", "bbb-mod"), ids(ModLoader.loadAll(mods, null)));
        });
        test("resolve: load_after orders but does not require", () -> {
            File mods = tmp();
            mod(mods, "aaa-mod", "\"load_after\":[\"zzz-mod\",\"not-installed\"]");
            mod(mods, "zzz-mod", "");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(Arrays.asList("zzz-mod", "aaa-mod"), ids(r));
            eq(0, r.problems.size());
        });
        test("resolve: missing dependency drops mod and its dependents", () -> {
            File mods = tmp();
            mod(mods, "mod-a", "\"dependencies\":[{\"id\":\"ghost-lib\"}]");
            mod(mods, "mod-b", "\"dependencies\":[{\"id\":\"mod-a\"}]");
            mod(mods, "mod-c", "");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(Arrays.asList("mod-c"), ids(r));
            yes(reason(r, "mod-a").contains("ghost-lib"), "names the missing lib");
            yes(reason(r, "mod-b").contains("mod-a"), "names the broken dependency");
        });
        test("resolve: dependency min_version", () -> {
            File mods = tmp();
            mod(mods, "lib-x", "\"version\":\"1.2.0\"");
            mod(mods, "needs-new", "\"dependencies\":[{\"id\":\"lib-x\",\"min_version\":\"1.3.0\"}]");
            mod(mods, "needs-old", "\"dependencies\":[{\"id\":\"lib-x\",\"min_version\":\"1.2\"}]");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(Arrays.asList("lib-x", "needs-old"), ids(r));
            yes(reason(r, "needs-new").contains("1.3.0"), "mentions needed version");
        });
        test("resolve: circular dependency is reported, not a hang", () -> {
            File mods = tmp();
            mod(mods, "cyc-a", "\"dependencies\":[{\"id\":\"cyc-b\"}]");
            mod(mods, "cyc-b", "\"dependencies\":[{\"id\":\"cyc-a\"}]");
            mod(mods, "fine-mod", "");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(Arrays.asList("fine-mod"), ids(r));
            eq(Arrays.asList("cyc-a", "cyc-b"), problemIds(r));
        });
        test("resolve: game version range", () -> {
            File mods = tmp();
            mod(mods, "old-only", "\"game_versions\":{\"max\":\"1.20.99\"}");
            mod(mods, "new-only", "\"game_versions\":{\"min\":\"1.21.0\"}");
            mod(mods, "any-ver", "");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, "1.26.62.1");
            eq(Arrays.asList("any-ver", "new-only"), ids(r));
            eq(Arrays.asList("old-only"), problemIds(r));
        });
        test("resolve: game version not checked when unknown", () -> {
            File mods = tmp();
            mod(mods, "old-only", "\"game_versions\":{\"max\":\"1.20.99\"}");
            eq(Arrays.asList("old-only"), ids(ModLoader.loadAll(mods, null)));
        });
        test("resolve: dependency dropped for game version cascades", () -> {
            File mods = tmp();
            mod(mods, "lib-old", "\"game_versions\":{\"max\":\"1.20.0\"}");
            mod(mods, "uses-lib", "\"dependencies\":[{\"id\":\"lib-old\"}]");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, "1.21.0");
            eq(0, r.mods.size());
            eq(2, r.problems.size());
        });
    }

    // -------------------------------------------------------------- discovery

    static void discoveryTests() {
        test("discover: missing folder is empty, not an error", () -> {
            ModLoader.LoadResult r = ModLoader.discover(new File(tmp(), "nope"));
            eq(0, r.mods.size());
            eq(0, r.problems.size());
        });
        test("discover: bad mods become problems, good ones still load", () -> {
            File mods = tmp();
            mod(mods, "good-mod", "");
            write(new File(mods, "broken/manifest.json"), "{oops");
            new File(mods, "no-manifest").mkdirs();
            write(new File(mods, "notes.txt"), "ignore me");
            new File(mods, ".hidden").mkdirs();
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(Arrays.asList("good-mod"), ids(r));
            eq(Arrays.asList("broken", "no-manifest"), problemIds(r));
        });
        test("discover: duplicate id, first wins", () -> {
            File mods = tmp();
            mod(mods, "dir-a", "");
            File d = mod(mods, "dir-b", "");
            write(new File(d, "manifest.json"), "{\"id\":\"dir-a\",\"name\":\"Dup\",\"version\":\"9.0.0\"}");
            ModLoader.LoadResult r = ModLoader.discover(mods);
            eq(1, r.mods.size());
            eq("1.0.0", r.mods.get(0).manifest.version);
            yes(r.problems.get(0).reason.contains("duplicate"), "duplicate reported");
        });
        test("discover: zip mod loads and builds", () -> {
            File mods = tmp();
            zip(new File(mods, "zipped.zip"),
                    "manifest.json", "{\"id\":\"zipped-mod\",\"name\":\"Z\",\"version\":\"1.0.0\"}",
                    "files/items/new_sword.json", "{\"hello\": 1}");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(Arrays.asList("zipped-mod"), ids(r));
            eq(0, r.problems.size());
            File out = new File(tmp(), "out");
            ModLoader.build(r.mods, out);
            eq("{\"hello\": 1}", read(new File(out, "items/new_sword.json")));
        });
        test("discover: .mend extension works too", () -> {
            File mods = tmp();
            zip(new File(mods, "thing.mend"),
                    "manifest.json", "{\"id\":\"thing-mod\",\"name\":\"T\",\"version\":\"1.0\"}");
            eq(Arrays.asList("thing-mod"), ids(ModLoader.loadAll(mods, null)));
        });
        test("discover: zip-slip path is rejected", () -> {
            File mods = tmp();
            zip(new File(mods, "evil.zip"),
                    "manifest.json", "{\"id\":\"evil-mod\",\"name\":\"E\",\"version\":\"1.0.0\"}",
                    "files/../../escape.txt", "pwned");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(0, r.mods.size());
            yes(r.problems.get(0).reason.contains("unsafe"), "unsafe path reported");
        });
        test("discover: symlink inside a folder mod is rejected", () -> {
            File mods = tmp();
            File d = mod(mods, "linky", "", "a.json", "{}");
            File secret = new File(tmp(), "secret.txt");
            write(secret, "top secret");
            Files.createSymbolicLink(new File(d, "files/leak.txt").toPath(), secret.toPath());
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(0, r.mods.size());
            yes(r.problems.get(0).reason.contains("symlink"), "symlink reported");
        });
        test("discover: corrupt zip is a problem", () -> {
            File mods = tmp();
            write(new File(mods, "bad.zip"), "this is not a zip");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(0, r.mods.size());
            eq(1, r.problems.size());
        });
        test("discover: manifest with a path-escaping files_dir is rejected", () -> {
            File mods = tmp();
            mod(mods, "sneaky", "\"files_dir\":\"../../etc\"");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            eq(0, r.mods.size());
            eq(1, r.problems.size());
        });
    }

    // ------------------------------------------------------------------ build

    static void buildTests() {
        test("build: later mod wins, conflict reported", () -> {
            File mods = tmp();
            mod(mods, "aaa-base", "", "entities/minecart.json", "{\"v\": \"base\"}");
            mod(mods, "bbb-over", "\"load_after\":[\"aaa-base\"]",
                    "entities/minecart.json", "{\"v\": \"over\"}", "items/extra.json", "{}");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            File out = new File(tmp(), "out");
            ModLoader.BuildReport rep = ModLoader.build(r.mods, out);
            eq("{\"v\": \"over\"}", read(new File(out, "entities/minecart.json")));
            eq(1, rep.conflicts.size());
            eq("entities/minecart.json", rep.conflicts.get(0).path);
            eq("bbb-over", rep.conflicts.get(0).winner);
            eq(Arrays.asList("aaa-base"), rep.conflicts.get(0).overridden);
            eq(2, rep.filesWritten);
        });
        test("build: json_merge combines objects", () -> {
            File mods = tmp();
            mod(mods, "aaa-base", "", "e.json", "{\"a\":{\"x\":1,\"y\":2},\"list\":[1,2]}");
            mod(mods, "bbb-patch", "\"json_merge\":true,\"load_after\":[\"aaa-base\"]",
                    "e.json", "{\"a\":{\"y\":9,\"z\":3},\"list\":[7]}");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            File out = new File(tmp(), "out");
            ModLoader.BuildReport rep = ModLoader.build(r.mods, out);
            eq(parse("{\"a\":{\"x\":1,\"y\":9,\"z\":3},\"list\":[7]}").toString(),
                    parse(read(new File(out, "e.json"))).toString());
            eq(Arrays.asList("e.json"), rep.jsonMerged);
            eq(0, rep.conflicts.size());
        });
        test("build: json_merge chains across three mods", () -> {
            File mods = tmp();
            mod(mods, "m1-mod", "", "e.json", "{\"a\":1}");
            mod(mods, "m2-mod", "\"json_merge\":true,\"load_after\":[\"m1-mod\"]", "e.json", "{\"b\":2}");
            mod(mods, "m3-mod", "\"json_merge\":true,\"load_after\":[\"m2-mod\"]", "e.json", "{\"c\":3}");
            File out = new File(tmp(), "out");
            ModLoader.build(ModLoader.loadAll(mods, null).mods, out);
            eq(parse("{\"a\":1,\"b\":2,\"c\":3}").toString(), parse(read(new File(out, "e.json"))).toString());
        });
        test("build: json_merge with invalid JSON falls back with a warning", () -> {
            File mods = tmp();
            mod(mods, "aaa-base", "", "e.json", "// comment\n{}");
            mod(mods, "bbb-patch", "\"json_merge\":true,\"load_after\":[\"aaa-base\"]", "e.json", "{\"a\":1}");
            ModLoader.BuildReport rep = ModLoader.build(ModLoader.loadAll(mods, null).mods, new File(tmp(), "out"));
            eq(1, rep.warnings.size());
            eq(1, rep.conflicts.size());
        });
        test("build: refuses to wipe a folder Mend did not create", () -> {
            File mods = tmp();
            mod(mods, "some-mod", "", "a.json", "{}");
            File out = tmp();
            write(new File(out, "my_world_backup.txt"), "do not delete");
            bad(() -> ModLoader.build(ModLoader.loadAll(mods, null).mods, out), "foreign folder");
            yes(new File(out, "my_world_backup.txt").exists(), "file survived");
        });
        test("build: rebuild replaces old output", () -> {
            File mods = tmp();
            mod(mods, "some-mod", "", "a.json", "{}", "b.json", "{}");
            File out = new File(tmp(), "out");
            ModLoader.build(ModLoader.loadAll(mods, null).mods, out);
            yes(new File(out, "b.json").exists(), "b exists after first build");
            new File(mods, "some-mod/files/b.json").delete();
            ModLoader.build(ModLoader.loadAll(mods, null).mods, out);
            no(new File(out, "b.json").exists(), "b gone after rebuild");
            yes(new File(out, ModLoader.BUILD_MARKER).exists(), "marker kept");
        });
        test("build: binary files copied byte-for-byte", () -> {
            File mods = tmp();
            File d = mod(mods, "tex-mod", "");
            File png = new File(d, "files/resource_packs/x/textures/a.png");
            png.getParentFile().mkdirs();
            byte[] blob = new byte[2560];
            for (int i = 0; i < blob.length; i++) blob[i] = (byte) i;
            Files.write(png.toPath(), blob);
            File out = new File(tmp(), "out");
            ModLoader.build(ModLoader.loadAll(mods, null).mods, out);
            yes(Arrays.equals(blob, Files.readAllBytes(new File(out, "resource_packs/x/textures/a.png").toPath())),
                    "bytes match");
        });
        test("build: binary files from a zip also match", () -> {
            File mods = tmp();
            File z = new File(mods, "bin.zip");
            byte[] blob = new byte[5000];
            for (int i = 0; i < blob.length; i++) blob[i] = (byte) (i * 7);
            try (ZipOutputStream zo = new ZipOutputStream(Files.newOutputStream(z.toPath()))) {
                zo.putNextEntry(new ZipEntry("manifest.json"));
                zo.write("{\"id\":\"bin-mod\",\"name\":\"B\",\"version\":\"1.0\"}".getBytes(StandardCharsets.UTF_8));
                zo.closeEntry();
                zo.putNextEntry(new ZipEntry("files/blob.bin"));
                zo.write(blob);
                zo.closeEntry();
            }
            File out = new File(tmp(), "out");
            ModLoader.build(ModLoader.loadAll(mods, null).mods, out);
            yes(Arrays.equals(blob, Files.readAllBytes(new File(out, "blob.bin").toPath())), "bytes match");
        });
        test("build: empty build is fine", () -> {
            ModLoader.BuildReport rep = ModLoader.build(new ArrayList<ModLoader.Mod>(), new File(tmp(), "out"));
            eq(0, rep.filesWritten);
        });
        test("build: report file written", () -> {
            File mods = tmp();
            mod(mods, "some-mod", "", "a.json", "{}");
            File out = new File(tmp(), "out");
            ModLoader.build(ModLoader.loadAll(mods, null).mods, out);
            Map<?, ?> rep = (Map<?, ?>) parse(read(new File(out, "mend_build.json")));
            eq(Collections.singletonList("some-mod"), rep.get("mods"));
            eq(Long.valueOf(1), rep.get("files_written"));
        });
        test("build: paths with spaces and unicode work", () -> {
            File mods = tmp();
            mod(mods, "uni-mod", "", "my folder/caf\u00e9 item.json", "{}");
            File out = new File(tmp(), "out");
            ModLoader.build(ModLoader.loadAll(mods, null).mods, out);
            yes(new File(out, "my folder/caf\u00e9 item.json").isFile(), "file exists");
        });
        test("build: bundled example mod builds", () -> {
            File examples = new File(System.getProperty("mend.examples", "../mend/examples/mods"));
            if (!examples.isDirectory()) return; // example lives in the Python project
            ModLoader.LoadResult r = ModLoader.loadAll(examples, "1.26.62.1");
            eq(0, r.problems.size());
            File out = new File(tmp(), "out");
            ModLoader.BuildReport rep = ModLoader.build(r.mods, out);
            eq(1, rep.filesWritten);
        });
        test("build: seen set sanity (no accidental shared state between builds)", () -> {
            File mods = tmp();
            mod(mods, "one-mod", "", "a.json", "{}");
            ModLoader.LoadResult r = ModLoader.loadAll(mods, null);
            ModLoader.BuildReport r1 = ModLoader.build(r.mods, new File(tmp(), "o1"));
            ModLoader.BuildReport r2 = ModLoader.build(r.mods, new File(tmp(), "o2"));
            eq(r1.filesWritten, r2.filesWritten);
            eq(new HashSet<String>(r1.mods), new HashSet<String>(r2.mods));
        });
    }
}
